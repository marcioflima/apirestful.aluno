package br.fametro.aluno.v1.controller;


import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.fametro.aluno.v1.dto.AlunoDto;
import br.fametro.aluno.v1.dto.AlunoDtoMapper;
import br.fametro.aluno.v1.model.Aluno;
import br.fametro.aluno.v1.service.ServicoAluno;

@RestController
@RequestMapping("/v1/aluno")
public class AlunoController {

	private final ServicoAluno alunoService;

	public AlunoController(ServicoAluno alunoService) {
		this.alunoService = alunoService;
	}

	@GetMapping
	public List<AlunoDto> listarTodos() {
		List<Aluno> aluno = alunoService.listarAlunos();
		return AlunoDtoMapper.toDtoList(aluno);
	}
	
	@GetMapping("/{id}")
	public AlunoDto obterPorId(@PathVariable Long id) {
		Aluno aluno = alunoService.buscarAlunoPorId(id);
		return AlunoDtoMapper.toDto(aluno);
	}

//	@GetMapping("/letra/{letra}")
//	public List<AlunoDto> listarPorLetraInicial(@PathVariable String letra) {
//		List<Aluno> aluno = alunoService.listarPorLetraInicial(letra);
//		return AlunoDtoMapper.toDtoList(aluno);
//	}

//	@GetMapping("/nome/{nome}")
//	public AlunoDto buscarPorNome(@PathVariable String nome) {
//		Aluno aluno = alunoService.buscarPorNome(nome);
//		return AlunoDtoMapper.toDto(aluno);
//	}

//	@GetMapping("/telefone/{telefone}")
//	public AlunoDto buscarPorTelefone(@PathVariable String telefone) {
//		Aluno aluno = alunoService.buscarPorTelefone(telefone);
//		return AlunoDtoMapper.toDto(aluno);
//	}

	@PostMapping
	public AlunoDto criarAluno(@RequestBody AlunoDto alunoDto) {
		Aluno aluno = AlunoDtoMapper.fromDto(alunoDto);
		aluno = alunoService.criarAluno(aluno);
		return AlunoDtoMapper.toDto(aluno);
	}

	@DeleteMapping("/{id}")
	public void deletarAluno(@PathVariable Long id) {
		alunoService.removerAluno(new Aluno(id));
	}
	
	@PutMapping("/{id}")
	public AlunoDto editarAluno(@PathVariable Long id, @RequestBody AlunoDto alunoDto) {
		alunoDto.setId(id);
		Aluno aluno = AlunoDtoMapper.fromDto(alunoDto);
		Aluno alunoAtualizado = alunoService.atualizarAluno(aluno);
	    return AlunoDtoMapper.toDto(alunoAtualizado);
	}

//    @PostMapping("/json/importar")
//    public void importarAlunos(@RequestBody List<AlunoDto> alunoImportados) {
//        alunoService.importarAlunos(AlunoDtoMapper.fromDtoList(alunoImportados));
//    }

//	@PostMapping("/csv/importar")
//	public void importarAlunos(@RequestParam("file") MultipartFile arquivo) throws IOException {
//		try (BufferedReader reader = new BufferedReader(new InputStreamReader(arquivo.getInputStream()))) {
//
//			List<AlunoDto> alunoDto = new ArrayList<>();
//			String linha;
//
//			for (int numLinha = 1; (linha = reader.readLine()) != null; numLinha++) {
//				// Divida a linha em campos usando a vírgula como delimitador
//
//				String[] campos = linha.split(";");
//				if (numLinha > 1 && campos.length == 3) { // Certifique-se de que há 3 campos: ID, Nome e Telefone
//					String id = campos[0].trim();
//					String nome = campos[1].trim();
//					String telefone = campos[2].trim();
//
//					// Crie um objeto AlunoDto com os dados lidos
//					AlunoDto alunoDto = new AlunoDto();
//					alunoDto.setId(Long.parseLong(id));
//					alunoDto.setNome(nome);
//					alunoDto.setTelefone(telefone);
//					alunoDto.add(alunoDto);
//
//				}
//			}
//
//			// Chame o serviço para importar o aluno
//			alunoService.importarAlunos(alunoDto);
//
//		} catch (IOException e) {
//			throw e;
//		}
//	}
//
//	@GetMapping("/csv/exportar")
//	public void exportar(HttpServletResponse response) {
//		response.setContentType("text/csv");
//		response.setHeader("Content-Disposition", "attachment; filename=\"aluno.csv\"");
//
//		List<Aluno> aluno = alunoService.listarTodos();
//
//		try (PrintWriter writer = response.getWriter()) {
//			// Escreve o cabeçalho do CSV
//			writer.println("ID;Nome;Telefone");
//
//			// Escreve os dados dos aluno no CSV
//			for (Aluno aluno : aluno) {
//				writer.println(aluno.getId() + ";" + aluno.getNome() + ";" + aluno.getTelefone());
//			}
//		} catch (IOException e) {
//			// Trate exceções, se necessário
//		}
//	}
}
