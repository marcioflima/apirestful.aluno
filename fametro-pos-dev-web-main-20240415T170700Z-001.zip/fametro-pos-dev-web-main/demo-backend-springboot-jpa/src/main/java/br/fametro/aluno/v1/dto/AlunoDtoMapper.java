package br.fametro.aluno.v1.dto;

import java.util.List;
import java.util.stream.Collectors;

import br.fametro.aluno.v1.model.Aluno;

public class AlunoDtoMapper {

    public static AlunoDto toDto(Aluno aluno) {
        AlunoDto dto = new AlunoDto();
        dto.setId(aluno.getId());
        dto.setNome(aluno.getNome());
        dto.setSexo(aluno.getSexo());
        dto.setNascimento(aluno.getNascimento());
        return dto;
    }
    
    public static Aluno fromDto(AlunoDto dto) {
        Aluno aluno = new Aluno();
        aluno.setId(dto.getId());
        aluno.setNome(dto.getNome());
        aluno.setSexo(dto.getSexo());
        aluno.setNascimento(dto.getNascimento());
        return aluno;
    }

    public static List<AlunoDto> toDtoList(List<Aluno> alunos) {
        return alunos.stream()
                .map(AlunoDtoMapper::toDto)
                .collect(Collectors.toList());
    }

    public static List<Aluno> fromDtoList(List<AlunoDto> dtos) {
        return dtos.stream()
                .map(AlunoDtoMapper::fromDto)
                .collect(Collectors.toList());
    }
}
