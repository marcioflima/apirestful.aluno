package br.fametro.aluno.v1.service;

import java.util.List;

import org.springframework.stereotype.Service;

import br.fametro.aluno.v1.model.Aluno;
import br.fametro.aluno.v1.repository.RepositorioAluno;

@Service
public class ServicoAluno {

	private RepositorioAluno repositorioAluno;

	public ServicoAluno(RepositorioAluno repositorioAluno) {
		this.repositorioAluno = repositorioAluno;
	}

	public List<Aluno> listarAlunos() {
		List<Aluno> alunos = repositorioAluno.findAll();
		if (alunos.isEmpty()) {
			throw new NegocioException("Nenhum aluno encontrado.");
		}
		return alunos;
	}

	public Aluno criarAluno(Aluno novaAluno) {
		return repositorioAluno.save(novaAluno);
	}

	public Aluno atualizarAluno(Aluno aluno) {
		repositorioAluno.save(aluno);
		return buscarAlunoPorId(aluno.getId());
	}
		
	public void removerAluno(Aluno aluno) {
		//Aluno alunoExistente = this.buscarAlunoPorId(aluno.getId());
		repositorioAluno.deleteById(aluno.getId());
	}
	
	public Aluno buscarAlunoPorId(Long id) {
        return repositorioAluno.findById(id).orElseThrow(() -> new NegocioException("Aluno não encontrado."));
    }

}
