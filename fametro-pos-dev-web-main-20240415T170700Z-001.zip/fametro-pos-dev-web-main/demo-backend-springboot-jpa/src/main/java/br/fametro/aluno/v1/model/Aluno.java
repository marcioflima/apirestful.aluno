package br.fametro.aluno.v1.model;

import java.time.LocalDateTime;

import br.fametro.aluno.util.LocalDateTimeAttributeConverter;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**	
 * Classe de domínio de negócio
 * @author marcos.eduardo
 */
@Entity
public class Aluno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;//titulo
    private String sexo;//descricao
    
    @Column
    @Convert(converter = LocalDateTimeAttributeConverter.class)
    private LocalDateTime nascimento;//data

    // Construtor
    public Aluno(Long id, String nome, String sexo) {
        this.id = id;
        this.nome = nome;
        this.sexo = sexo;
    }
    public Aluno(Long id, String nome, String sexo, LocalDateTime nascimento) {
        this.id = id;
        this.nome = nome;
        this.sexo = sexo;
        this.nascimento = nascimento;
        //this.nascimento = nascimento != null ? LocalDateTime.parse(nascimento) : null;
    }
    // Construtor
    public Aluno(String nome, String sexo) {
        this.nome = nome;
        this.sexo = sexo;
    }
    public Aluno(Long id) {
        this.id = id;
    }
    public Aluno() {
	}
    
	// Getters e setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
	public LocalDateTime getNascimento() {
		return nascimento;
	}
	public void setNascimento(LocalDateTime nascimento) {
		this.nascimento = nascimento;
	}
    
}
